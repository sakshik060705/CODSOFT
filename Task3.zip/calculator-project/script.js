const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");

let input = "";

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    let value = btn.textContent;

    if (value === "C") {
      input = "";
      display.value = "";
      return;
    }

    if (value === "=") {
      try {
        input = eval(input);
        display.value = input;
      } catch {
        display.value = "Error";
      }
      return;
    }

    input += value;
    display.value = input;
  });
});
